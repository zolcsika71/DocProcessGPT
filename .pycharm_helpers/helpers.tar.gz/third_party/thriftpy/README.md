#Thriftpy with dependencies

Python Console protocol description: 
`/community/python/helpers/pydev/pydev_console/console.thrift`

Script for Java classes generation: 
`/community/python/thrift/console-compile.sh`
